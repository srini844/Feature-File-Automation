package com.framework.pages;


import com.framework.testng.api.base.ProjectSpecificMethods;

public class ConveyancePage extends ProjectSpecificMethods {

	
}
