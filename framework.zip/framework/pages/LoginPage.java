package com.framework.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;



public class LoginPage extends ProjectSpecificMethods {
	

	public LoginPage enterUserName() throws InterruptedException {
		try {
			type(locateElement(Locators.XPATH, "//input[@autocomplete='username']|//input[@id='okta-signin-username']"), getValueFromConfig("userName"));
			reportStep("Successfully entered user name : " + getValueFromConfig("userName"), "Pass",true);
		} catch (Exception e) {
			reportStep("Unable to enter user name : " + getValueFromConfig("userName"), "Fail",true);
		e.printStackTrace();
			
			
		}
		return this;
	}
	
	public LoginPage enterPassword() throws InterruptedException {
		try {
			type(locateElement(Locators.XPATH, "//input[@autocomplete='current-password']|//input[@id='okta-signin-password']"),DecodePassword(getValueFromConfig("password")));
			reportStep("Successfully entered Password", "Pass",true);
			
			
		} catch (Exception e) {
			reportStep("Unable to enter Password", "Fail",true);
			e.printStackTrace();
			
		
		}
		return this;
	}
	
	public LoginPage clickSubmit() throws FileNotFoundException, IOException {
		try {
			click(locateElement(Locators.XPATH, "//input[@value='Sign in']|//input[@value='Sign In']"));
			reportStep("Clicked login button", "Pass",true);
		} catch (Exception e) {
		reportStep("Failed to click login button", "Fail",true);
		e.printStackTrace();
		
		}
		return this;
	}
	
	public LoginPage userAuthentication() throws FileNotFoundException, IOException {
		try {			
			enterUserName();
			enterPassword();
			clickSubmit();		
		} catch (Exception e) {
		reportStep("Failed to click login button", "Fail",true);
		e.printStackTrace();
		
		}
		return this;
	
	}

	
	public Gemini_HomePage OktaAuthentication() throws FileNotFoundException, IOException {
		try {
			click(locateElement(Locators.XPATH, "//input[@value='Send Push']"));	
			/*click(locateElement(Locators.XPATH, "//a[contains(text(),'enter code')]"));			
			pause(10000);
			click(locateElement(Locators.XPATH, "//a[contains(text(),'Verify')]"));
			pause(2000);*/
			Thread.sleep(10000);
			reportStep("Successfully Passed Okta Authentication", "Pass",true);
		} catch (Exception e) {
			reportStep("Okta Authentication Failed", "Fail",true);
			e.printStackTrace();		
		}
		return new Gemini_HomePage();
	}
	
	



}
