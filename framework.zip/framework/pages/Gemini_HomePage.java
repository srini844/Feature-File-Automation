package com.framework.pages;

import javax.management.relation.Role;

import org.openqa.selenium.NoSuchElementException;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class Gemini_HomePage extends ProjectSpecificMethods {

	public Gemini_HomePage select_Country_Role(String countryCode,String role) throws Exception {
		boolean country = false;
		try {
			waitTillElementVisible(locateElement(Locators.XPATH, "//input[@id='fx-gn-countryFlag-"+countryCode+"']"));
			country =verifyDisplayed(locateElement(Locators.XPATH, "//input[@id='fx-gn-countryFlag-"+countryCode+"']"));
			reportStep("Searching for country =>"+countryCode, "Pass", true);
			reportStep("Searching for country =>"+role, "Pass", true);
			try {
				if (country) {
					String[] splitRole = role.split(":");
					click(locateElement(Locators.XPATH, "//select[@id='fx-gn-role-dropdown-"+countryCode+"']"));
					selectDropDownUsingValue(locateElement(Locators.XPATH, "//select[@id='fx-gn-role-dropdown-"+countryCode+"']"), splitRole[1]);
					waitTillElementVisible(locateElement(Locators.XPATH, "//button[@id='btnContextSelection']"));
					click(locateElement(Locators.XPATH, "//button[@id='btnContextSelection']"));
				}
			} catch (NoSuchElementException nse) {
				reportStep("Unable to select the role in gemini application", "Fail", true);
				throw new Exception();		
			}
		} catch (NoSuchElementException e) {
			reportStep("Country selection is not available on the home page", "Fail", true);
			e.printStackTrace();
		}
		return new Gemini_HomePage();
	}
}
